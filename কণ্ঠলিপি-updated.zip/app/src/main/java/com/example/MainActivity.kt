package com.example

import android.os.Bundle
import android.speech.tts.Voice
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.MyApplicationTheme

val BgColor = Color(0xFF0F1117)
val SurfaceColor = Color(0xFF1A1D27)
val BorderColor = Color(0xFF2D3142)
val AccentColor = Color(0xFF7C6FF7)
val Accent2Color = Color(0xFFA78BFA)
val TextColor = Color(0xFFE8E9F0)
val MutedColor = Color(0xFF94A3B8)
val LabelColor = Color(0xFF6B7280)
val ErrorColor = Color(0xFFF87171)
val SuccessColor = Color(0xFF34D399)

val AccentGradient = Brush.linearGradient(
    colors = listOf(AccentColor, Accent2Color)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = BgColor
                ) {
                    VoiceGeneratorScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceGeneratorScreen(viewModel: VoiceViewModel = viewModel()) {
    val text by viewModel.text.collectAsState()
    val voices by viewModel.voices.collectAsState()
    val selectedVoice by viewModel.selectedVoice.collectAsState()
    val rate by viewModel.rate.collectAsState()
    val pitch by viewModel.pitch.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val statusType by viewModel.statusType.collectAsState()
    val statusMessage by viewModel.statusMessage.collectAsState()
    
    val focusManager = LocalFocusManager.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgColor)
            .systemBarsPadding()
    ) {
        // HEADER
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .padding(horizontal = 24.dp, vertical = 24.dp)
                .padding(top = 8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .background(AccentGradient, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎙️", fontSize = 24.sp)
            }
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = "ভয়েস জেনারেটর",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = (-0.5).sp
                )
                Text(
                    text = "AI এর মাধ্যমে আপনার লেখা শুনুন",
                    color = MutedColor,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 2.dp)
                )
            }
        }

        // MAIN CONTENT
        Column(
            modifier = Modifier
                .weight(1f)
                .padding(horizontal = 24.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Text Area
            Column(modifier = Modifier.heightIn(min = 200.dp)) {
                Text(
                    text = "আপনার লেখা",
                    color = LabelColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
                )
                Box(modifier = Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = text,
                        onValueChange = { viewModel.updateText(it) },
                        placeholder = {
                            Text("এখানে বাংলা বা ইংরেজি লেখা লিখুন...", color = MutedColor)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .defaultMinSize(minHeight = 220.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = AccentColor,
                            unfocusedBorderColor = BorderColor,
                            focusedTextColor = TextColor,
                            unfocusedTextColor = TextColor,
                            focusedContainerColor = SurfaceColor,
                            unfocusedContainerColor = SurfaceColor
                        ),
                        shape = RoundedCornerShape(24.dp)
                    )
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(end = 20.dp, bottom = 16.dp)
                            .background(BgColor.copy(alpha = 0.5f), CircleShape)
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "${text.length} অক্ষর",
                            color = LabelColor,
                            fontSize = 10.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                }
            }

            // Controls Card
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(SurfaceColor, RoundedCornerShape(24.dp))
                    .border(1.dp, BorderColor, RoundedCornerShape(24.dp))
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Voice Select
                Column {
                    Text(
                        text = "ভয়েস নির্বাচন করুন",
                        color = LabelColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(bottom = 12.dp)
                    )
                    var expanded by remember { mutableStateOf(false) }
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            readOnly = true,
                            value = selectedVoice?.let { "${if (it.locale.language.startsWith("bn")) "🇧🇩 " else ""}${it.name} (${it.locale.language})" }
                                ?: "লোড হচ্ছে...",
                            onValueChange = {},
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccentColor,
                                unfocusedBorderColor = BorderColor,
                                focusedTextColor = TextColor,
                                unfocusedTextColor = TextColor,
                                focusedContainerColor = BgColor,
                                unfocusedContainerColor = BgColor,
                                focusedTrailingIconColor = LabelColor,
                                unfocusedTrailingIconColor = LabelColor
                            ),
                            shape = RoundedCornerShape(16.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false },
                            modifier = Modifier.background(SurfaceColor)
                        ) {
                            if (voices.isEmpty()) {
                                DropdownMenuItem(
                                    text = { Text("ভয়েস পাওয়া যায়নি", color = TextColor) },
                                    onClick = { expanded = false }
                                )
                            } else {
                                voices.forEach { voice ->
                                    DropdownMenuItem(
                                        text = {
                                            val isBn = voice.locale.language.startsWith("bn")
                                            Text(
                                                text = "${if (isBn) "🇧🇩 " else ""}${voice.name} (${voice.locale.language})",
                                                color = TextColor
                                            )
                                        },
                                        onClick = {
                                            viewModel.selectVoice(voice)
                                            expanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }
                }

                // Rate & Pitch Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(24.dp)
                ) {
                    // Rate
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("গতি", color = LabelColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(String.format("%.1f×", rate), color = Accent2Color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = rate,
                            onValueChange = { viewModel.updateRate(it) },
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor, inactiveTrackColor = BorderColor)
                        )
                    }
                    
                    // Pitch
                    Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("পিচ", color = LabelColor, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(String.format("%.1f", pitch), color = Accent2Color, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = pitch,
                            onValueChange = { viewModel.updatePitch(it) },
                            valueRange = 0.0f..2.0f,
                            colors = SliderDefaults.colors(thumbColor = AccentColor, activeTrackColor = AccentColor, inactiveTrackColor = BorderColor)
                        )
                    }
                }
            }

            // Status Bar
            if (statusType != StatusType.IDLE) {
                val (bgColor, borderColor, textColor) = when (statusType) {
                    StatusType.PLAYING -> Triple(
                        AccentColor.copy(alpha = 0.1f),
                        AccentColor.copy(alpha = 0.2f),
                        Accent2Color
                    )
                    StatusType.DONE -> Triple(
                        SuccessColor.copy(alpha = 0.1f),
                        SuccessColor.copy(alpha = 0.2f),
                        SuccessColor
                    )
                    StatusType.ERROR -> Triple(
                        ErrorColor.copy(alpha = 0.1f),
                        ErrorColor.copy(alpha = 0.2f),
                        ErrorColor
                    )
                    else -> Triple(Color.Transparent, Color.Transparent, Color.Transparent)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(bgColor, RoundedCornerShape(16.dp))
                        .border(1.dp, borderColor, RoundedCornerShape(16.dp))
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (statusType == StatusType.PLAYING) {
                        PulseDot(color = textColor)
                    } else {
                        Box(modifier = Modifier
                            .size(8.dp)
                            .background(textColor, CircleShape))
                    }
                    Text(
                        text = statusMessage,
                        color = textColor,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
        }

        // FOOTER
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    focusManager.clearFocus()
                    viewModel.speak()
                },
                modifier = Modifier
                    .weight(2f)
                    .height(56.dp),
                enabled = !isSpeaking,
                shape = CircleShape,
                colors = ButtonDefaults.buttonColors(
                    containerColor = AccentColor,
                    disabledContainerColor = AccentColor.copy(alpha = 0.5f),
                    contentColor = Color.White
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.PlayArrow, contentDescription = "Play", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("বলুন", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            OutlinedButton(
                onClick = { viewModel.stop() },
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp),
                enabled = isSpeaking,
                shape = CircleShape,
                border = BorderStroke(1.dp, BorderColor),
                colors = ButtonDefaults.outlinedButtonColors(
                    contentColor = MutedColor,
                    disabledContentColor = BorderColor
                )
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Stop, contentDescription = "Stop", modifier = Modifier.size(20.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("থামুন", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }
        }
    }
}

@Composable
fun PulseDot(color: Color) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.3f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Box(
        modifier = Modifier
            .size(8.dp)
            .alpha(alpha)
            .background(color, CircleShape)
    )
}
