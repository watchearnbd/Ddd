package com.example

import android.app.Application
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class StatusType {
    IDLE, PLAYING, DONE, ERROR
}

class VoiceViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null

    private val _text = MutableStateFlow("")
    val text: StateFlow<String> = _text.asStateFlow()

    private val _voices = MutableStateFlow<List<Voice>>(emptyList())
    val voices: StateFlow<List<Voice>> = _voices.asStateFlow()

    private val _selectedVoice = MutableStateFlow<Voice?>(null)
    val selectedVoice: StateFlow<Voice?> = _selectedVoice.asStateFlow()

    private val _rate = MutableStateFlow(1.0f)
    val rate: StateFlow<Float> = _rate.asStateFlow()

    private val _pitch = MutableStateFlow(1.0f)
    val pitch: StateFlow<Float> = _pitch.asStateFlow()

    private val _statusType = MutableStateFlow(StatusType.IDLE)
    val statusType: StateFlow<StatusType> = _statusType.asStateFlow()

    private val _statusMessage = MutableStateFlow("Ready")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    init {
        tts = TextToSpeech(application, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val availableVoices = tts?.voices?.toList() ?: emptyList()
            // Prioritize Bengali voices
            val sortedVoices = availableVoices.sortedByDescending { it.locale.language.startsWith("bn") }
            _voices.value = sortedVoices
            if (sortedVoices.isNotEmpty()) {
                _selectedVoice.value = sortedVoices.first()
            }

            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _statusType.value = StatusType.PLAYING
                    _statusMessage.value = "বলছে..." // Speaking...
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _statusType.value = StatusType.DONE
                    _statusMessage.value = "বলা শেষ হয়েছে ✓" // Done speaking
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _statusType.value = StatusType.ERROR
                    _statusMessage.value = "সমস্যা হয়েছে" // Error occurred
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _statusType.value = StatusType.ERROR
                    _statusMessage.value = "সমস্যা হয়েছে: $errorCode"
                    _isSpeaking.value = false
                }
            })
        } else {
            _statusType.value = StatusType.ERROR
            _statusMessage.value = "Text-to-Speech initialization failed."
        }
    }

    fun updateText(newText: String) {
        _text.value = newText
    }

    fun selectVoice(voice: Voice) {
        _selectedVoice.value = voice
    }

    fun updateRate(newRate: Float) {
        _rate.value = newRate
    }

    fun updatePitch(newPitch: Float) {
        _pitch.value = newPitch
    }

    fun speak() {
        val currentText = _text.value.trim()
        if (currentText.isEmpty()) {
            _statusType.value = StatusType.ERROR
            _statusMessage.value = "প্রথমে কিছু লিখুন!" // Write something first!
            return
        }
        
        tts?.stop()

        _selectedVoice.value?.let { tts?.voice = it }
        tts?.setSpeechRate(_rate.value)
        tts?.setPitch(_pitch.value)

        val params = Bundle()
        params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "VOICE_GEN_ID")
        
        tts?.speak(currentText, TextToSpeech.QUEUE_FLUSH, params, "VOICE_GEN_ID")
    }

    fun stop() {
        tts?.stop()
        _statusType.value = StatusType.DONE
        _statusMessage.value = "থামানো হয়েছে" // Stopped
        _isSpeaking.value = false
    }

    override fun onCleared() {
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
